package com.provectus.kafka.ui.serde.schemaregistry;

public enum MessageFormat {
  AVRO,
  JSON,
  STRING,
  PROTOBUF
}
