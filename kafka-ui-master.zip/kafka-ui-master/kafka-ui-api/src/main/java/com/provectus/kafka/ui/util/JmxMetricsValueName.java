package com.provectus.kafka.ui.util;

public enum JmxMetricsValueName {
  Count,
  OneMinuteRate,
  FifteenMinuteRate,
  FiveMinuteRate,
  MeanRate
}
