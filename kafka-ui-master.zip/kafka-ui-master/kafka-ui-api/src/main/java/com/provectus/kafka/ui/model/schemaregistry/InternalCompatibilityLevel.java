package com.provectus.kafka.ui.model.schemaregistry;

import lombok.Data;

@Data
public class InternalCompatibilityLevel {
  private String compatibilityLevel;
}
