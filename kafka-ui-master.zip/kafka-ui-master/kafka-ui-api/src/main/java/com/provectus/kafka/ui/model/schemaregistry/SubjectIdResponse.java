package com.provectus.kafka.ui.model.schemaregistry;

import lombok.Data;

@Data
public class SubjectIdResponse {
  private Integer id;
}
