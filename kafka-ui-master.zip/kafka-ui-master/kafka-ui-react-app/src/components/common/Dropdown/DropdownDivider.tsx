import React from 'react';

const DropdownDivider: React.FC = () => <hr className="dropdown-divider" />;

export default DropdownDivider;
