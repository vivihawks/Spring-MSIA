import React from 'react';
import { shallow } from 'enzyme';
import { ServerStatus } from 'generated-sources';
import { clusterBrokersPath, clusterTopicsPath } from 'lib/paths';
import ClusterWidget from 'components/Dashboard/ClustersWidget/ClusterWidget';

import { offlineCluster, onlineCluster } from './fixtures';

describe('ClusterWidget', () => {
  describe('when cluster is online', () => {
    it('renders with correct tag', () => {
      const tag = shallow(<ClusterWidget cluster={onlineCluster} />).find(
        '.tag'
      );
      expect(tag.hasClass('is-success')).toBeTruthy();
      expect(tag.text()).toEqual(ServerStatus.ONLINE);
    });

    it('renders table', () => {
      const table = shallow(<ClusterWidget cluster={onlineCluster} />).find(
        'table'
      );
      expect(table.hasClass('is-fullwidth')).toBeTruthy();

      expect(
        table.find(`NavLink[to="${clusterBrokersPath(onlineCluster.name)}"]`)
          .exists
      ).toBeTruthy();
      expect(
        table.find(`NavLink[to="${clusterTopicsPath(onlineCluster.name)}"]`)
          .exists
      ).toBeTruthy();
    });

    it('matches snapshot', () => {
      expect(
        shallow(<ClusterWidget cluster={onlineCluster} />)
      ).toMatchSnapshot();
    });
  });

  describe('when cluster is offline', () => {
    it('renders with correct tag', () => {
      const tag = shallow(<ClusterWidget cluster={offlineCluster} />).find(
        '.tag'
      );

      expect(tag.hasClass('is-danger')).toBeTruthy();
      expect(tag.text()).toEqual(ServerStatus.OFFLINE);
    });

    it('renders table', () => {
      const table = shallow(<ClusterWidget cluster={offlineCluster} />).find(
        'table'
      );
      expect(table.hasClass('is-fullwidth')).toBeTruthy();

      expect(
        table.find(`NavLink[to="${clusterBrokersPath(onlineCluster.name)}"]`)
          .exists
      ).toBeTruthy();
      expect(
        table.find(`NavLink[to="${clusterTopicsPath(onlineCluster.name)}"]`)
          .exists
      ).toBeTruthy();
    });

    it('matches snapshot', () => {
      expect(
        shallow(<ClusterWidget cluster={offlineCluster} />)
      ).toMatchSnapshot();
    });
  });

  describe('when cluster is read-only', () => {
    it('renders the tag', () => {
      expect(
        shallow(
          <ClusterWidget cluster={{ ...onlineCluster, readOnly: true }} />
        )
          .find('.title')
          .childAt(1)
          .text()
      ).toEqual('readonly');
    });
  });
});
