import { Cluster } from 'generated-sources';

export type ClusterName = Cluster['name'];

export type ClusterState = Cluster[];
