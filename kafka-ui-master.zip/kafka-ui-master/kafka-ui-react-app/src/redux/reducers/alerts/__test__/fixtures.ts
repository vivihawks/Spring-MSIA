export const failurePayload1 = {
  title: 'title',
  message: 'message',
  subject: 'topic-1',
};

export const failurePayload2 = {
  ...failurePayload1,
  subject: 'topic-2',
};
