package com.thoughtmechanix.licenses.services;

import org.springframework.stereotype.Service;

@Service
public class OrganizationService {
}
