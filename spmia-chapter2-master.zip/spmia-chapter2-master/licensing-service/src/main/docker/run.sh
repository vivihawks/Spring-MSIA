#!/bin/sh
echo "********************************************************"
echo "Starting License Server"
echo "********************************************************"
java -jar /usr/local/licensingservice/@project.build.finalName@.jar
